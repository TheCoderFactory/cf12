(function ($) {
    "use strict";
    $(document).ready(function(){
        $('.ct-js-datetimePicker').datetimepicker({
            pickTime: false
        });
    })
}(jQuery));
