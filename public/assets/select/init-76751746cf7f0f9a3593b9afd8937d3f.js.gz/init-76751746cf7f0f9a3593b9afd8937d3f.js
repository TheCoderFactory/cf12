(function ($) {
    "use strict";
    $(document).ready(function(){

	    $("#select").select2();

    }); // /document.ready
})(jQuery);
